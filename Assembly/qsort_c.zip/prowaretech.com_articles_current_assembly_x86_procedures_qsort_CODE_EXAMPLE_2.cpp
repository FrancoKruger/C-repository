#include <stdlib.h>
#include <time.h>

extern "C" void qisort(void *array[], const unsigned size, int (*compare_func)(const void *element1, const void *element2));

int compare_ascending(const int a, const int b)
{
	return a - b;
}

int array[1000000];

int main()
{
	srand(time(NULL));
	int i;
	unsigned size = sizeof(array)/sizeof(void*);
	for(i = 0; i < size; i++)
	{
		if(rand() % 3 == 0)
			array[i] = -rand();
		else
			array[i] = rand();
	}
	qisort((void **)array, size, (int (*)(const void*,const void*))compare_ascending);
	return 0;
}
