#include <stdio.h>
#include <string.h>

extern "C" void qisort(void *array[], const unsigned size, int (*compare_func)(const void *element1, const void *element2));

class Person
{
	char last[100], first[100];
	Person(){}
public:
	Person(const char *lastname, const char *firstname)
	{
		strcpy_s(last, lastname);
		strcpy_s(first, firstname);
	}
	const char *lastname() const {return last;}
	const char *firstname() const {return first;}
};

int compare_people(const Person *p1, const Person *p2)
{
	if(int i = strcmp(p1->lastname(), p2->lastname()))
		return i;
	return strcmp(p1->firstname(), p2->firstname());
}

int main()
{
	Person *array[] = {
		new Person("Smith","John"),
		new Person("Smith","Jane"),
		new Person("Bleaux","Joe"),
		new Person("Jackson","Miles"),
		new Person("Jackson","Andrew")
	};
	unsigned size = sizeof(array)/sizeof(void*);
	qisort((void **)array, size, (int (*)(const void*,const void*))compare_people);
	for(int i = 0; i < size; delete array[i++])
		printf("%s, %s\r\n", array[i]->lastname(), array[i]->firstname());
	return 0;
}
