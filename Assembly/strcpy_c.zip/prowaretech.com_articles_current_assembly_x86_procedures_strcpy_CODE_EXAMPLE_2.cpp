#include <stdlib.h>

extern "C" char * strcpy_asm(char *destination, const char *source);

char str[100], *end;
int length;

end = strcpy_asm(str, "How ");
end = strcpy_asm(end, "now ");
end = strcpy_asm(end, "brown ");
end = strcpy_asm(end, "cow!");

length = end - str;

// or simply

length = strcpy_asm(strcpy_asm(strcpy_asm(strcpy_asm(str, "How "), "now "), "brown "), "cow!") - str;

// str == "How now brown cow!"
// length == 18
